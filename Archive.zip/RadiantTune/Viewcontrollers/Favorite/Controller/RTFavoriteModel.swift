//
//  RTFavoriteModel.swift
//  RadiantTune
//
//  Created by Aaribna Gurung on 5/29/24.
//

import Foundation

struct RTFavoriteModel  {
    var id: Int?
    var imageName: String
    var stationName: String
    var location: String
    var genre: String

}
