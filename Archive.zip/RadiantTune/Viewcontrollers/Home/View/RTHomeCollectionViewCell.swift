//
//  RTHomeCollectionViewCell.swift
//  RadiantTune
//
//  Created by 杜乐乐 on 2024-05-13.
//

import UIKit

class RTHomeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var iconImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }

}
