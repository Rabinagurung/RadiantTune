//
//  RTBaseViewController.swift
//  RadiantTune
//
//  Created by 杜乐乐 on 2024-05-11.
//

import UIKit
import SVProgressHUD
import Kingfisher

class RTBaseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    func showHUDWithMessege(messege: String) {
        
    }


}
